//Mirjana Bijelic 2019230099//
//Homework number 1, exercise 1//
package mirjanabijelic2019230099;


public class StudentRank {
    String studentName;
    int testOne;
    int testTwo;

public double tests(){
    double sumTests;
    sumTests = (testOne*0.3) + (testTwo*0.7);
    return sumTests;
}
}
