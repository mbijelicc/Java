//Mirjana Bijelic 2019230099//
//Homework number 2, exercise 2//
package mirjana.bijelic.pkg2019230099;

import java.util.Random;
import java.util.Scanner;

public class Main {
    
    public static int Celebrity(int[][] array){
        int c = 0;
        int c1 = 0;
        int f = 0;
        int sI = 0;
        for (int i = 0; i < array.length; i++) {
            c = 0;
            for (int[] array1 : array) {
                if (array1[i] != 1) {
                    break;
                } else {
                    c++;
                }
            }
            if(c == array.length) {
                c1 = 0;
                for (int j = 0; j < array.length; j++) {
                    if(i != j)
                        if(array[i][j] == 0)
                            c1++;
                        else
                            break;

                }
                if(c1 == array.length-1) {
                    f++;
                    sI = i;
                }
            }
        }

        if(f == 1)
            return sI;
        else
            return -1;
    }

    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number of persons: ");
        int n = s.nextInt();
        int[][] array = new int[n][n];

        Random r = new Random();

        System.out.println("The (random) acquaintance matrix of these persons is: ");
        for (int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++){
                if(i == j)
                    array[i][j] = 1;
                else
                    array[i][j] = r.nextInt(2);
                System.out.print(array[i][j]+" ");
            }
            System.out.println();
        }

        int resultCelebrity = Celebrity(array);
        if(resultCelebrity > -1)
            System.out.println("There is a celebrity.:) It is " + resultCelebrity + ".");
        else
            System.out.println("There are no celebrities.:(");

       
    }
    
}
