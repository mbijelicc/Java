//Mirjana Bijelic 2019230099//
//Midterm 1 project//
package midterm1;


public class Club {
    String name;
    int points;
   private String nameOfTheCoach;
    
   public  Club(String name, int points, String nameOfTheCoach){
     this.name = name;
     this.points = points;
     this.nameOfTheCoach = nameOfTheCoach;
    }
   
   public String getCoach() {
    return nameOfTheCoach;
  }
   
   public void setCoach(String newCoach) {
    this.nameOfTheCoach = newCoach;
  }
    
    public Club(){
        
    }
    
    
}
