//Mirjana Bijelic 2019230099//
//Midterm 1 project//
package midterm1;

import java.util.Scanner;
import java.lang.reflect.Array;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        Club[] clubarr = new Club[5];       //Name of the club array
        
        clubarr[0] = new Club();
        clubarr[1] = new Club();
        clubarr[2] = new Club();
        clubarr[3] = new Club();
        clubarr[4] = new Club();
        
        clubarr[0].name = "Zvezda";
        clubarr[1].name = "Art";
        clubarr[2].name = "Partizan";
        clubarr[3].name = "Ras";
        clubarr[4].name = "Girl";
        
        
        Coach[] coacharr = new Coach[5];    //Name of the coach array
        
        coacharr[0] = new Coach();
        coacharr[1] = new Coach();
        coacharr[2] = new Coach();
        coacharr[3] = new Coach();
        coacharr[4] = new Coach();
        
        coacharr[0].name = "Stefan Stefic";
        coacharr[1].name = "Ivan Ivic";
        coacharr[2].name = "Luka Lukic";
        coacharr[3].name = "Mirka Mirkic";
        coacharr[4].name = "Kosta Kostic";
        
        int points;
        
        for(int i=0; i<clubarr.length; i++){
            System.out.printf("Enter number of points for the club %s from the first game : " , clubarr[i].name);
            points = scan.nextInt();
            clubarr[i].points = points;
        }
        
        Club temp = new Club();
        Coach temp1 = new Coach();
        
        for (int i = 0; i < clubarr.length; i++) {
            for (int j = i+1; j < clubarr.length; j++) {
                if(clubarr[i].points < clubarr[j].points){
                    temp = clubarr[i];
                    clubarr[i] = clubarr[j];
                    clubarr[j] = temp;
                    temp1 = coacharr[i];
                           coacharr[i] = coacharr[j];
                           coacharr[j] = temp1;
                }
            }
        } 
        
                
        System.out.println();
        System.out.print("Rank after the first game is: ");
        for (int i = 0; i < clubarr.length ; i++) {
            if(i != clubarr.length - 1)
                System.out.print(clubarr[i].name + ", ");
            else
                System.out.println(clubarr[i].name);
        }
        
        System.out.println();
        System.out.println("First on the list after firts game is: " +clubarr[0].name);
        System.out.println();
       
        System.out.println("Name of the coach of the first club in the list is: " +coacharr[0].name);
        System.out.println();
        
    }
    
}

        
        